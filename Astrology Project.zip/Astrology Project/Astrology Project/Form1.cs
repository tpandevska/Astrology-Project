﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Astrology_Project
{
    public partial class Form1 : Form
    {
        public ZodiacSign myZodiac { get; set; }
        public Form1()
        {
            InitializeComponent();
            myZodiac = new ZodiacSign();
        }
          

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnZodiacSign_Click(object sender, EventArgs e)
        {
            CalculateZodiacSign form = new CalculateZodiacSign();
            DialogResult result = form.ShowDialog();
            if(result == DialogResult.OK)
            {
                form.zodiacSign = myZodiac;

               
                lblZodiac.Text = String.Format("Your zodiac sign is: {0}", form.zodiacSign.sign);
                lblZodiac.Visible = true;

            }
            




        }

        private void cbHoroscopeSign_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbHoroscopeSign.SelectedIndex != -1)
            {
                lblZodiac.Text = String.Format("Your zodiac sign is: {0}", cbHoroscopeSign.SelectedItem);
                lblZodiac.Visible = true;
               
            }
            else
                lblZodiac.Visible = false;
        }

       

    }
}

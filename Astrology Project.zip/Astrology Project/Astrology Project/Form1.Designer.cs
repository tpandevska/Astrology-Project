﻿namespace Astrology_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.btnZodiacSign = new System.Windows.Forms.Button();
            this.btnAsceningSign = new System.Windows.Forms.Button();
            this.btnMoonSign = new System.Windows.Forms.Button();
            this.btnDaily = new System.Windows.Forms.Button();
            this.btnMonthly = new System.Windows.Forms.Button();
            this.btnYearly = new System.Windows.Forms.Button();
            this.cbHoroscopeSign = new System.Windows.Forms.ComboBox();
            this.lblZodiac = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Astrology";
            // 
            // btnZodiacSign
            // 
            this.btnZodiacSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZodiacSign.Location = new System.Drawing.Point(27, 418);
            this.btnZodiacSign.Name = "btnZodiacSign";
            this.btnZodiacSign.Size = new System.Drawing.Size(208, 34);
            this.btnZodiacSign.TabIndex = 2;
            this.btnZodiacSign.Text = "Calculate Zodiac Sign";
            this.btnZodiacSign.UseVisualStyleBackColor = true;
            this.btnZodiacSign.Click += new System.EventHandler(this.btnZodiacSign_Click);
            // 
            // btnAsceningSign
            // 
            this.btnAsceningSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsceningSign.Location = new System.Drawing.Point(27, 498);
            this.btnAsceningSign.Name = "btnAsceningSign";
            this.btnAsceningSign.Size = new System.Drawing.Size(208, 34);
            this.btnAsceningSign.TabIndex = 3;
            this.btnAsceningSign.Text = "Calculate Ascending Sign";
            this.btnAsceningSign.UseVisualStyleBackColor = true;
            // 
            // btnMoonSign
            // 
            this.btnMoonSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoonSign.Location = new System.Drawing.Point(27, 458);
            this.btnMoonSign.Name = "btnMoonSign";
            this.btnMoonSign.Size = new System.Drawing.Size(208, 34);
            this.btnMoonSign.TabIndex = 4;
            this.btnMoonSign.Text = "Calculate Moon Sign";
            this.btnMoonSign.UseVisualStyleBackColor = true;
            // 
            // btnDaily
            // 
            this.btnDaily.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDaily.Location = new System.Drawing.Point(661, 12);
            this.btnDaily.Name = "btnDaily";
            this.btnDaily.Size = new System.Drawing.Size(208, 34);
            this.btnDaily.TabIndex = 5;
            this.btnDaily.Text = "Daily Horoscope";
            this.btnDaily.UseVisualStyleBackColor = true;
            // 
            // btnMonthly
            // 
            this.btnMonthly.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMonthly.Location = new System.Drawing.Point(661, 52);
            this.btnMonthly.Name = "btnMonthly";
            this.btnMonthly.Size = new System.Drawing.Size(208, 34);
            this.btnMonthly.TabIndex = 6;
            this.btnMonthly.Text = "Monthly Horoscope";
            this.btnMonthly.UseVisualStyleBackColor = true;
            this.btnMonthly.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnYearly
            // 
            this.btnYearly.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYearly.Location = new System.Drawing.Point(661, 92);
            this.btnYearly.Name = "btnYearly";
            this.btnYearly.Size = new System.Drawing.Size(208, 34);
            this.btnYearly.TabIndex = 7;
            this.btnYearly.Text = "Yearly Horoscope";
            this.btnYearly.UseVisualStyleBackColor = true;
            // 
            // cbHoroscopeSign
            // 
            this.cbHoroscopeSign.BackColor = System.Drawing.SystemColors.Window;
            this.cbHoroscopeSign.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.cbHoroscopeSign.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbHoroscopeSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbHoroscopeSign.FormattingEnabled = true;
            this.cbHoroscopeSign.Items.AddRange(new object[] {
            "Aries",
            "Taurus",
            "Gemini",
            "Cancer",
            "Leo",
            "Virgo",
            "Libra",
            "Scorpio",
            "Sagittarius",
            "Capricorn",
            "Aquarius",
            "Pisces"});
            this.cbHoroscopeSign.Location = new System.Drawing.Point(12, 76);
            this.cbHoroscopeSign.Name = "cbHoroscopeSign";
            this.cbHoroscopeSign.Size = new System.Drawing.Size(208, 33);
            this.cbHoroscopeSign.TabIndex = 8;
            this.cbHoroscopeSign.Text = "Choose your sign!";
            this.cbHoroscopeSign.SelectedIndexChanged += new System.EventHandler(this.cbHoroscopeSign_SelectedIndexChanged);
            // 
            // lblZodiac
            // 
            this.lblZodiac.AutoSize = true;
            this.lblZodiac.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZodiac.Location = new System.Drawing.Point(609, 508);
            this.lblZodiac.Name = "lblZodiac";
            this.lblZodiac.Size = new System.Drawing.Size(178, 24);
            this.lblZodiac.TabIndex = 9;
            this.lblZodiac.Text = "Your zodiac sign is: ";
            this.lblZodiac.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblZodiac.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(904, 583);
            this.Controls.Add(this.lblZodiac);
            this.Controls.Add(this.cbHoroscopeSign);
            this.Controls.Add(this.btnYearly);
            this.Controls.Add(this.btnMonthly);
            this.Controls.Add(this.btnDaily);
            this.Controls.Add(this.btnMoonSign);
            this.Controls.Add(this.btnAsceningSign);
            this.Controls.Add(this.btnZodiacSign);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnZodiacSign;
        private System.Windows.Forms.Button btnAsceningSign;
        private System.Windows.Forms.Button btnMoonSign;
        private System.Windows.Forms.Button btnDaily;
        private System.Windows.Forms.Button btnMonthly;
        private System.Windows.Forms.Button btnYearly;
        private System.Windows.Forms.ComboBox cbHoroscopeSign;
        private System.Windows.Forms.Label lblZodiac;
    }
}

